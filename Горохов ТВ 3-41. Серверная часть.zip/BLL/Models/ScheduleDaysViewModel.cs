﻿namespace BLL
{
    public class ScheduleDaysViewModel
    {
        public List<ScheduleDayDTO> Schedule { get; set; }
    }
}
